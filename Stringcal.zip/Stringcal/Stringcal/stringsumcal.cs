﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stringcal
{
   public  class stringsumcal

    {
       public static int arraystartindex = 0;
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter string");
           string str = Console.ReadLine();
           Stringcalculator(str);
           Console.ReadKey();

        }
        public static void Stringcalculator(string str)
        {
            int sum = calculatesum(str, finddelimeter(str), arraystartindex);
            Console.WriteLine(sum);
        }
     

       private static int calculatesum(string Str, string[] arrdelimeter, int arraystartindex)
        {
            if (string.IsNullOrEmpty(Str))
            {
                return 0;
            }
            else
            {
                int i = 0;
                try
                {
                   
                    String[] withnewline = Str.Split( new[] {"\\n","\\r","\\r\\n"},StringSplitOptions.RemoveEmptyEntries);
                    for (int j = arraystartindex; j <= withnewline.Length - 1; j++)
                    {
                        String[] words = withnewline[j].Split(arrdelimeter, StringSplitOptions.RemoveEmptyEntries);
                       
                            foreach (string word in words)
                            {
                                int result;
                                if (int.TryParse(word, out result))
                                {
                                    int k = Math.Sign(result);
                                    if (k == -1)
                                    {
                                        throw new InvalidOperationException("Negative numbers are not allowed in the string.\n The number '" + result + "' caused this exception");
                                    }
                                    else
                                    {
                                        if (result < 1000)
                                        {
                                            i += result;
                                        }
                                    }

                                }


                            }
                       
                    }
                    return i;   
                   
                }
                catch(Exception ex)
                {
                   
                    Console.WriteLine(ex.Message);
                    return 0;
                }
               
            }

        }

       private static string[] finddelimeter(string str)
       {
           string[] delimeter;
           if (str.StartsWith("//"))
           {

               str = str.Substring(2, str.Length - 2);

               String[] withnewline = str.Split(new[] { "\\n", "\\r", "\\r\\n" }, StringSplitOptions.RemoveEmptyEntries);
               delimeter = withnewline[0].Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);
               arraystartindex = 1;
               return delimeter;

           }
           else
           {
               delimeter = new string[] { "," };
               arraystartindex = 0;
               return delimeter;

           }


       }
   }
}
