﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Stringcal;
namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void task1()
        {
            stringsumcal.Stringcalculator("1,2,5");
         
        }
        [TestMethod]
        public void task2()
        {

            stringsumcal.Stringcalculator("1\n,2,3");

        }
        [TestMethod]
        public void task3()
        {

            stringsumcal.Stringcalculator("//@\n2@3@8");

        }
        [TestMethod]
        public void task4()
        {
            stringsumcal.Stringcalculator("1,2,-5");

        }
        [TestMethod]
        public void bonus1()
        {

            stringsumcal.Stringcalculator("2,1001");

        }
        [TestMethod]
        public void bonus2()
        {

            stringsumcal.Stringcalculator("//***\n1***2***3");

        }
        [TestMethod]
        public void bonus3()
        {

            stringsumcal.Stringcalculator("//$,@\n1$2@3");

        }
        [TestMethod]
        public void bonus4()
        {

            stringsumcal.Stringcalculator("//$$$,@@@\n1$$$2@@@3");

        }
    }
}
